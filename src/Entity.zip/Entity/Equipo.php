<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;

/**
 * Equipo
 *
 * @ORM\Table(name="equipo", indexes={@ORM\Index(name="fk_equipo_usuario1_idx", columns={"Usuario_email"})})
 * @ORM\Entity(repositoryClass="App\Repository\EquipoRepository")
 * @UniqueEntity(fields={"nombre"}, message="Ya hay un equipo que se llama así.")
 */
class Equipo
{
    /**
     * @var int
     *
     * @ORM\Column(name="idequipo", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $idequipo;

    /**
     * @var string
     * @Assert\NotBlank(message="Este campo no puede dejarse vacío.")
     * @Assert\Length(min=2,max=40,minMessage="Longitud mínima 2 caracteres",maxMessage="Longitud máxima 40 carácteres")
     * @Assert\Regex(
     *      pattern="/^[ÁÉÍÓÚA-Z]+/",
     *      message="El valor no puede ser un valor numérico/no emmpieza por mayúscula."
     * )
     * @ORM\Column(name="Nombre", type="string", length=45, nullable=false)
     */
    private $nombre;

    /**
     * @var \Usuario
     *
     *
     * @Assert\NotBlank(message="Este campo no puede dejarse vacío.")
     * @ORM\ManyToOne(targetEntity="Usuario")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="usuario_email", referencedColumnName="email")
     * })
     */
    private $usuarioEmail;

    /**
    *  Bidirectional - uno a muchos (INVERSE SIDE) Para poner atributos extras en una relación N-M
    *
    * @ORM\OneToMany(targetEntity="EquipoContienePokemon", mappedBy="equipoIdequipo", cascade={"all"})
    *
    */
    private $equipotienepokes;

    /**
     * @return Collection|Pokemon[]
     */
    public function getPokes(): Collection
    {
        return $this->equipotienepokes;
    }

    public function addPokes(Pokemon $poke): self
    {
        if (!$this->equipotienepokes->contains($poke)) {
            $this->equipotienepokes[] = $poke;
            $poke->addEquipo($this);
        }

        return $this;
    }

    public function removeformathaspoke(Pokemon $poke): self
    {
        if ($this->equipotienepokes->contains($poke)) {
            $this->equipotienepokes->removeElement($poke);
            $poke->removeEquipo($this);
        }

        return $this;
    }

    public function getIdequipo(): ?int
    {
        return $this->idequipo;
    }

    public function getNombre(): ?string
    {
        return $this->nombre;
    }

    public function setNombre(string $nombre): self
    {
        $this->nombre = $nombre;

        return $this;
    }

    public function getUsuarioEmail(): ?Usuario
    {
        return $this->usuarioEmail;
    }

    public function setUsuarioEmail(?Usuario $usuarioEmail): self
    {
        $this->usuarioEmail = $usuarioEmail;

        return $this;
    }

    public function __toString()
    {
            return $this->getNombre();
        
    }


}
